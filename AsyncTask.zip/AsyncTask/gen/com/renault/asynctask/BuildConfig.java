/** Automatically generated file. DO NOT MODIFY */
package com.renault.asynctask;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}