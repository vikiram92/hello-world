package com.renault.asynctask;

import java.io.File;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.renault.utils.BitmapConverter;
import com.renault.utils.Logger;
import com.renault.utils.ProgressBar;
import com.renault.utils.UrlBitmapConverter;

public class MainActivity extends ActionBarActivity implements OnClickListener {

	LinearLayout hiddenLayout, runnableLayout;
	Button clicktoLoad, clicktoRunnable, clickHandler;
	Bitmap urlBitmap, imageBitmap, runnableUrl, runnableImage;
	ImageView urlImage, localImage, runurlImage, runlocalImage;
	String urlLink = "http://cdn.3news.co.nz/3news/AM/2014/5/24/345592/Renault_1200.jpg";
	String filePath = Environment.getExternalStorageDirectory()
			.getAbsolutePath() + "/QieZi/pictures/IMG_20150113_135426.jpg";
	File myImage = new File(filePath);

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		hiddenLayout = (LinearLayout) findViewById(R.id.hidden_layout);
		runnableLayout = (LinearLayout) findViewById(R.id.runnable_layout);
		urlImage = (ImageView) findViewById(R.id.img_url);
		runlocalImage = (ImageView) findViewById(R.id.runnable_local);
		runurlImage = (ImageView) findViewById(R.id.runnable_url);
		urlImage = (ImageView) findViewById(R.id.img_url);
		localImage = (ImageView) findViewById(R.id.img_local);
		clicktoLoad = (Button) findViewById(R.id.click);
		clicktoRunnable = (Button) findViewById(R.id.click_runnable);
		clickHandler = (Button) findViewById(R.id.click_handler);
		clicktoLoad.setOnClickListener(this);
		clicktoRunnable.setOnClickListener(this);
		clickHandler.setOnClickListener(this);
	}

	public class AsyncImageLoadTask extends AsyncTask<Void, String, Void> {

		@Override
		protected void onPreExecute() {
			Log.d("onPreExecute", "onPreExecute");
			// TODO Auto-generated method stub
		}

		@Override
		protected Void doInBackground(Void... params) {
			Log.d("doInBackground", "doInBackground");
			// TODO Auto-generated method stub
			Logger.log(filePath);
			Logger.log(myImage+"");
			if (myImage.exists()) {
				imageBitmap = BitmapConverter.bitmapConverter(filePath);
				Logger.log(String.valueOf(imageBitmap));
			}

			if (UrlBitmapConverter.isNetworkAvailable(MainActivity.this)) {
				publishProgress("Downloading image from url please wait....");
				urlBitmap = UrlBitmapConverter.downloadImage(urlLink);

			}
			return null;
		}

		@Override
		protected void onProgressUpdate(String... values) {
			Log.d("onProgressUpdate", "onProgressUpdate");
			// TODO Auto-generated method stub
			Toast.makeText(getApplicationContext(), values[0],
					Toast.LENGTH_LONG).show();
		}

		@Override
		protected void onPostExecute(Void result) {
			Log.d("onPostExecute", "onPostExecute");
			// TODO Auto-generated method stub
			if (urlBitmap != null || imageBitmap != null) {
				hiddenLayout.setVisibility(View.VISIBLE);

				if (urlBitmap != null)
					urlImage.setImageBitmap(urlBitmap);
				else
					Toast.makeText(getApplicationContext(),
							"No internet connection", Toast.LENGTH_LONG).show();
				if (imageBitmap != null) {
					localImage.setImageBitmap(imageBitmap);
				} else
					Toast.makeText(getApplicationContext(),
							"Local Image Not Found", Toast.LENGTH_LONG).show();
			} else {
				Toast.makeText(getApplicationContext(), "No Images Found",
						Toast.LENGTH_LONG).show();
			}
		}

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	Handler handler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			Bundle receivedBundle = msg.getData();
			String receivedMsg = receivedBundle.getString("Toast msg");
			Toast.makeText(getApplicationContext(), receivedMsg, Toast.LENGTH_LONG).show();
		}	
	};
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v == clicktoLoad) {
			new AsyncImageLoadTask().execute();
		}
		else if(v == clicktoRunnable) {
			Toast.makeText(getApplicationContext(), "Downloading image please wait", Toast.LENGTH_SHORT).show();
			Thread backgroundThread = new Thread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					if (UrlBitmapConverter.isNetworkAvailable(MainActivity.this)) {
						runnableUrl = UrlBitmapConverter.downloadImage(urlLink);
						runurlImage.post(new Runnable() {
							
							@Override
							public void run() {
								// TODO Auto-generated method stub
								runnableLayout.setVisibility(View.VISIBLE);
								runurlImage.setImageBitmap(runnableUrl);
								
							}
						});
					}
					else
					{
						runOnUiThread(new Runnable() {
							
							@Override
							public void run() {
								// TODO Auto-generated method stub
								Toast.makeText(getApplicationContext(), "Sorry no internet connection", Toast.LENGTH_SHORT).show();
							}
						});
					}
					if (myImage.exists()) {
						runnableImage = BitmapConverter.bitmapConverter(filePath);
						runlocalImage.postDelayed(new Runnable() {
							
							@Override
							public void run() {
								// TODO Auto-generated method stub
								Toast.makeText(getApplicationContext(), "Local Image Downloaded", Toast.LENGTH_SHORT).show();
								runnableLayout.setVisibility(View.VISIBLE);
								runlocalImage.setImageBitmap(runnableImage);
								
							}
						}, 10000);
					}
				}
			});
			if(backgroundThread.isAlive())
			{
				Log.d("Alive",backgroundThread.getState()+"");
				Log.d("Alive",backgroundThread.isAlive()+"");
				Toast.makeText(getApplicationContext(), "It was running.Please wait", Toast.LENGTH_SHORT).show();
			}
			else
			{
				Log.d("Thread Started",backgroundThread.getState()+"");
				Log.d("Thread Started",backgroundThread.isAlive()+"");
				backgroundThread.start();
				Log.d("Next Line Thread Started",backgroundThread.getState()+"");
			}
		}
		else if(v == clickHandler) {
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					Message msg =  handler.obtainMessage();
					Bundle handlerBundle = new Bundle();
					handlerBundle.putString("Toast msg", "This toast is displayed using handler");
					msg.setData(handlerBundle);
					handler.sendMessage(msg);
				}
			}).start();;
		}

	}
}
