package com.renault.utils;

import java.io.IOException;
import java.io.InputStream;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.PasswordAuthentication;
import java.net.URL;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

public class UrlBitmapConverter {

	public static Bitmap downloadImage(String url) {
		
		Bitmap bitmap = null;
		InputStream stream = null;
		BitmapFactory.Options bmOptions = new BitmapFactory.Options();
		bmOptions.inSampleSize = 1;

		try {
			Log.d("Starting","Connection");
			stream = getHttpConnection(url);
			Log.d("Stream",stream.toString());
			Log.d("Connected","Http");
			bitmap = BitmapFactory.decodeStream(stream, null, bmOptions);
			Log.d("Bitmap",bitmap+"");
			if(stream != null)
				stream.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return bitmap;
	}

	public static InputStream getHttpConnection(String urlString) throws IOException {
		
		InputStream stream = null;
		URL url = new URL(urlString);
		HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
		httpConnection.setReadTimeout(10000);
        httpConnection.setConnectTimeout(15000);
		httpConnection.setRequestMethod("GET");
        httpConnection.setDoInput(true);
		httpConnection.connect();
		if(httpConnection.usingProxy()) {
			Log.d("Working Proxy",String.valueOf( httpConnection.usingProxy()));
			Authenticator authenticator = new Authenticator() {
				
				public PasswordAuthentication getPasswordAuthentication() {
					Log.d("Setting","Password Authentication");
					PasswordAuthentication pa  = new PasswordAuthentication("z012914","qwerty46".toCharArray());
					return pa;
				}
			};
			Authenticator.setDefault(authenticator);
		}
		try {
			
			Log.d("Response Code",String.valueOf(httpConnection.getResponseCode()));
			
			if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
				Log.d("Got","Response");
				stream = httpConnection.getInputStream();
			}
			
		} catch (Exception ex) {
			Log.d("Internet Connection Problem", ex.toString());
			ex.printStackTrace();
		}
		return stream;
	}

	public static boolean isNetworkAvailable(Activity context) {
		
		ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		
		NetworkInfo[] info = cm.getAllNetworkInfo();
		
		for (int i = 0; i < info.length; i++) {
			
			if (info[i].getState() == NetworkInfo.State.CONNECTED) {
				Log.d("Network connection", "Exists");
				return true;
			}
			else
				Log.d("No Network connection", "Exists");
		}
		return false;
	}
}
