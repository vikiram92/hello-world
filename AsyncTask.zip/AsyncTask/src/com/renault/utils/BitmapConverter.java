package com.renault.utils;

import java.io.File;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class BitmapConverter {

	public static Bitmap bitmapConverter(String filePath) {
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inSampleSize = 8;
		File fileUri = new File(filePath);
		Bitmap bitmap = BitmapFactory.decodeFile(fileUri.getPath(), options);
		
		return bitmap;

	}
}
